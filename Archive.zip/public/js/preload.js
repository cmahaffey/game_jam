var BedJam = BedJam || {};

BedJam.Preload = function(){};

BedJam.Preload.prototype = {
  preload: function() {
    // shows loading screen
   this.preloadBar = this.add.sprite(this.game.world.centerX, this.game.world.centerY + 128, 'preloadbar');
   this.preloadBar.anchor.setTo(0.5);
   this.load.setPreloadSprite(this.preloadBar);

  // load game assets
  this.load.tilemap('level1', '/assets/tilemaps/level1.json', null, Phaser.Tilemap.TILED_JSON);
  this.load.tilemap('level2', '/assets/tilemaps/level2.json', null, Phaser.Tilemap.TILED_JSON);
  this.load.spritesheet('player', '/assets/images/dude.png', 32, 48);
  this.load.image('gameTilessophie', '/assets/images/tiles3.png');
  this.load.image('gameTilessophie2', '/assets/images/basictiles.png');
  this.load.image('thehole', '/assets/images/thehole.png');





  },

  create: function() {
    console.log('preload state loaded');
    this.state.start('MainMenu');
  }
};
